const express = require("express");
const Database = require("better-sqlite3");
const cors = require("cors");
const path = require("path");
const multer = require("multer");
const fs = require("fs");

const app = express();
const port = 3000;
const ADMIN_SECRET = "tajneheslo";

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
app.use("/uploads", express.static(uploadDir));

const storage = multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + "-" + file.originalname;
        cb(null, uniqueName);
    }
});
const upload = multer({ storage });

const db = new Database(path.join(__dirname, "db", "poems.db"));
db.prepare(`
    CREATE TABLE IF NOT EXISTS poems (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL
    )
`).run();

db.prepare(`
    CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        poem_id INTEGER,
        filename TEXT,
        FOREIGN KEY(poem_id) REFERENCES poems(id)
    )
`).run();

function isAdmin(req, res, next) {
    const token = req.headers['x-admin-token'];
    if (token === ADMIN_SECRET) {
        next();
    } else {
        res.status(403).json({ error: "Forbidden – admin only" });
    }
}

app.get("/poems", (req, res) => {
    const poems = db.prepare("SELECT * FROM poems ORDER BY id DESC").all();
    const files = db.prepare("SELECT * FROM files").all();
    const poemsWithFiles = poems.map(poem => {
        const attached = files.filter(f => f.poem_id === poem.id);
        return { ...poem, files: attached };
    });
    res.json(poemsWithFiles);
});

app.post("/poems", upload.array("files"), (req, res) => {
    const { title, content } = req.body;
    if (!title || !content) return res.status(400).json({ error: "Missing fields" });

    const stmt = db.prepare("INSERT INTO poems (title, content) VALUES (?, ?)");
    const info = stmt.run(title, content);
    const poemId = info.lastInsertRowid;

    if (req.files && req.files.length > 0) {
        const fileStmt = db.prepare("INSERT INTO files (poem_id, filename) VALUES (?, ?)");
        for (const file of req.files) {
            fileStmt.run(poemId, file.filename);
        }
    }

    res.status(201).json({ success: true, id: poemId });
});

app.listen(port, () => {
    console.log(`🚀 Server běží na http://localhost:${port}`);
});
